
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'aweperi',
  applicationName: 'eventbooking-crud-api',
  appUid: '3kr479y3nCSf2LBXqw',
  orgUid: '34951f94-8db2-4703-b8f3-027560ebcbd1',
  deploymentUid: '93f4891f-ee37-4e74-b3f6-a83abea5e27e',
  serviceName: 'eventbooking-crud-api',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.2',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'get-all-events', timeout: 6 };

try {
  const userHandler = require('./src/handlers.js');
  module.exports.handler = serverlessSDK.handler(userHandler.getAllEvents, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}