"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.bookEvent = exports.createEvent = void 0;
const uuid_1 = require("uuid");
const yup = __importStar(require("yup"));
const db_1 = require("./db");
const headers = {
    "content-type": "application/json",
};
const eventsTable = "EventsTable";
const eventSchema = yup.object().shape({
    title: yup.string().required(),
    description: yup.string().required(),
    artist: yup.number().required(),
    attendees: yup.array().notRequired(),
});
const attendeeSchema = yup.object().shape({
    username: yup.string().required()
});
class HttpError extends Error {
    constructor(statusCode, body = {}) {
        super(JSON.stringify(body));
        this.statusCode = statusCode;
    }
}
const handleError = (err) => {
    if (err instanceof yup.ValidationError) {
        return {
            statusCode: 400,
            headers,
            body: JSON.stringify({
                errors: err.errors,
            }),
        };
    }
    if (err instanceof SyntaxError) {
        return {
            statusCode: 400,
            headers,
            body: JSON.stringify({ error: `invalid request body format : "${err.message}"` }),
        };
    }
    if (err instanceof HttpError) {
        return {
            statusCode: err.statusCode,
            body: err.message
        };
    }
    throw err;
};
const createEvent = async (event) => {
    try {
        const reqBody = JSON.parse(event.body);
        await eventSchema.validate(reqBody, { abortEarly: false });
        const eventItem = Object.assign({ eventId: (0, uuid_1.v4)() }, reqBody);
        await db_1.ddbClient
            .put({
            TableName: eventsTable,
            Item: eventItem,
        })
            .promise();
        return {
            statusCode: 201,
            headers,
            body: JSON.stringify(eventItem),
        };
    }
    catch (err) {
        throw err;
    }
};
exports.createEvent = createEvent;
const bookEvent = async (event) => {
    var _a;
    try {
        const id = (_a = event.pathParameters) === null || _a === void 0 ? void 0 : _a.eventId;
        const reqBody = JSON.parse(event.body);
        let attendees = [];
        await attendeeSchema.validate(reqBody, { abortEarly: false });
        const eventItemToBeUpdated = fetchProductById(id);
        attendees.push(reqBody);
        const eventItem = Object.assign(Object.assign({}, eventItemToBeUpdated), { attendees: attendees, eventId: id });
        await db_1.ddbClient
            .put({
            TableName: eventsTable,
            Item: eventItem,
        })
            .promise();
        return {
            statusCode: 200,
            headers,
            body: JSON.stringify(eventItem),
        };
    }
    catch (err) {
        return handleError(err);
    }
};
exports.bookEvent = bookEvent;
const fetchProductById = async (id) => {
    const output = await db_1.ddbClient
        .get({
        TableName: eventsTable,
        Key: {
            productID: id,
        },
    })
        .promise();
    if (!output.Item) {
        throw new HttpError(404, { error: "not found" });
    }
    return output.Item;
};
//# sourceMappingURL=handlers.js.map