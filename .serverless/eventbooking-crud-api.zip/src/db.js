"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ddbClient = void 0;
const aws_sdk_1 = __importDefault(require("aws-sdk"));
const REGION = "us-east-1";
const ddbClient = new aws_sdk_1.default.DynamoDB.DocumentClient({ region: REGION });
exports.ddbClient = ddbClient;
//# sourceMappingURL=db.js.map